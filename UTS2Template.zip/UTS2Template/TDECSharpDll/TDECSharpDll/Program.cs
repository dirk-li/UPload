﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TDECSharpDll
{
    public static class Program
    {
        static ObjectTestClass objectTest = new ObjectTestClass();
        public static bool StartTest(string[] args, StringBuilder pisData, StringBuilder pisErrorMessage, StringBuilder testResultInfo)
        {
            bool bReResult = true;
            string dataResult = "";
            StringBuilder testData = new StringBuilder();
            int cmd = int.Parse(args[3].Split(':')[0]);
            switch (cmd)
            {
                case 1://Auto Initial Comport
                    if (objectTest.AutoInitialCom(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Open Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Open Com Exception!;");
                        bReResult = false;
                    }
                    break;
                case 2://Initial Comport
                    if (objectTest.InitialCom(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Open Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Open Com Exception!;");
                        bReResult = false;
                    }
                    break;
                case 3://Query
                    if (objectTest.QueryData(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Query Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Query Com Exception!;");
                        bReResult = false;
                    }
                    break;
                case 4://Write
                    if (objectTest.WriteData(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Write Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Write Com Exception!;");
                        bReResult = false;
                    }
                    break;
                case 5://CloseCom
                    if (objectTest.CloseCom(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Write Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Write Com Exception!;");
                        bReResult = false;
                    }
                    break;
                case 6://CloseAllCom
                    if (objectTest.CloseALLCom(pisData, testResultInfo, args))
                    {
                        //testResultInfo.Append("Write Com success!;");
                    }
                    else
                    {
                        //testResultInfo.Append("Write Com Exception!;");
                        bReResult = false;
                    }
                    break;
            }

            return bReResult;
        }
    }
}
